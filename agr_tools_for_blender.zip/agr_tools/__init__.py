bl_info = {
    'name': 'AGR tools',
    'blender': (2, 93, 0),
    'category': 'Object',
    'version': (1, 2, 0),
    'author': 'adenex',
    'description': 'Set of tools for the advancedfx addon. This will help you clean up your scene.',
}

import bpy
import json
import time
import re
from bpy_extras.io_utils import ExportHelper

PROPS = [
    ('remove_w_knives', bpy.props.BoolProperty(name='Remove w_knives', default=True, description='Deletes all knives (except pov)')),
    ('remove_dropped_knives', bpy.props.BoolProperty(name='Remove *dropped* knives', default=True, description='Deletes all *dropped* knives')),
    ('remove_w_guns', bpy.props.BoolProperty(name='Remove w_guns', default=True, description='Deletes all guns (except pov)')),
    ('remove_dropped_guns', bpy.props.BoolProperty(name='Remove *dropped* guns', default=False, description='Deletes all *dropped* guns')),
    ('remove_w_pistols', bpy.props.BoolProperty(name='Remove w_pistols', default=True, description='Deletes all pistols (except pov)')),
    ('remove_dropped_pistols', bpy.props.BoolProperty(name='Remove *dropped* pistols', default=False, description='Deletes all *dropped* pistols')),
    ('remove_w_nades', bpy.props.BoolProperty(name='Remove nades', default=True, description='Deletes all grenades (except pov)')),
    ('remove_dropped_nades', bpy.props.BoolProperty(name='Remove *dropped* nades', default=True, description='Deletes all *dropped* grenades')),
    ('remove_w_c4', bpy.props.BoolProperty(name='Remove c4', default=True, description='Deletes c4 (except pov)')),
    ('remove_dropped_c4', bpy.props.BoolProperty(name='Remove *dropped* c4', default=True, description='Deletes *dropped* c4')),
    ('remove_pov', bpy.props.BoolProperty(name='Remove POV', default=False, description='Completely removes POV (viewmodels)')),
    ('remove_duplicates', bpy.props.BoolProperty(name='Remove duplicates', default=True, description='Removes all duplicated gloves and sleeves')),
    ('remove_misc', bpy.props.BoolProperty(name='Remove misc', default=True, description='Removes stickers, defuser kits and stattrack models')),
    ('place_animations', bpy.props.BoolProperty(name='Place all animations at (0,0,0)', default=True, description='Prevents animations from appearing in other sequences. This option will take some time to process')),
    ('offset', bpy.props.IntProperty(name='Z Offset', default=-5)),
]


def fixer():  # fix bad naming
    bpy.ops.object.select_all(action='DESELECT')
    for obj in bpy.context.scene.objects:
        if re.match(r'afx.\w+.\w+.+', obj.name):
            obj.name = re.sub(r'(afx.\w+.\w+)(.+)', r'\1.mdl', obj.name)


def w_knives():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_knife_*[!d].mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def w_knives_dropped():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_knife_*dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def w_guns():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_rif_*[!d].mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='* w_mach_*[!d].mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='* w_shot_*[!d].mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='* w_smg_*[!d].mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='* w_snip_*[!d].mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def w_guns_dropped():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_rif_*dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='* w_mach_*dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='* w_shot_*dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='* w_smg_*dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='* w_snip_*dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def w_pistols():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_pist_*[!d].mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def w_pistols_dropped():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_pist_*dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def w_nades():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_eq_*[!d].mdl**', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def w_nades_dropped():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_eq_*dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)

def w_c4():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_ied.mdl', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def w_c4_dropped():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* w_ied_dropped.mdl*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def pov():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='* v_*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def duplicates():
    def finder(pat):
        bpy.ops.object.select_all(action='DESELECT')
        bpy.ops.object.select_pattern(pattern=pat, case_sensitive=False, extend=True)
        selected_anims = bpy.context.selected_objects
        sel_anims = []
        for i in selected_anims:
            sel_anims.append(i.name)
        if len(sel_anims) > 1:
            del_list = sel_anims[1:]
            bpy.ops.object.select_all(action='DESELECT')
            for a in del_list:
                bpy.ops.object.select_pattern(pattern=a, case_sensitive=False, extend=True)
                bpy.ops.object.delete(use_global=True)
                bpy.ops.object.select_all(action='DESELECT')

    finder('*v_sleeve*')
    finder('*v_glove*')


def misc():
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='*defuser*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='*decal*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='*sticker*', case_sensitive=False, extend=True)
    bpy.ops.object.select_pattern(pattern='*stattrack*', case_sensitive=False, extend=True)
    bpy.ops.object.select_more()
    bpy.ops.object.delete(use_global=True)


def z_offset(name, value):
    bpy.data.objects[name].location.z = value


def anims_zero():
    print('------\nWorking')
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.select_pattern(pattern='*.mdl*', case_sensitive=False, extend=True)
    bpy.context.scene.frame_current = 1
    selected_anims = bpy.context.selected_objects
    sel_anims = []
    for i in selected_anims:
        sel_anims.append(i.name)
    for a in sel_anims:
        bpy.ops.anim.keyframe_insert_menu(type='Location')
        bpy.data.objects[a].location = (0, 0, 0)
        z_offset(a, bpy.context.scene.offset)
        bpy.ops.anim.keyframe_insert_menu(type='Location')
    bpy.ops.object.select_all(action='DESELECT')


class AgrTools(bpy.types.Operator):
    bl_idname = 'opr.agr_tools'
    bl_label = 'Agr Tools'

    def execute(self, context):
        fixer()
        if context.scene.remove_w_knives:
            w_knives()
        if context.scene.remove_dropped_knives:
            w_knives_dropped()
        if context.scene.remove_w_guns:
            w_guns()
        if context.scene.remove_dropped_guns:
            w_guns_dropped()
        if context.scene.remove_w_pistols:
            w_pistols()
        if context.scene.remove_dropped_pistols:
            w_pistols_dropped()
        if context.scene.remove_w_nades:
            w_nades()
        if context.scene.remove_dropped_nades:
            w_nades_dropped()
        if context.scene.remove_w_c4:
            w_c4()
        if context.scene.remove_dropped_c4:
            w_c4_dropped()
        if context.scene.remove_pov:
            pov()
        if context.scene.remove_duplicates:
            duplicates()
        if context.scene.remove_misc:
            misc()
        if context.scene.place_animations:
            anims_zero()

        return {'FINISHED'}


class AgrVisibility(bpy.types.Operator, ExportHelper):
    bl_idname = 'opr.export_visibility'  # important since its how bpy.ops.import_test.some_data is constructed
    bl_label = 'Export Visibility'

    @classmethod
    def description(cls, context, properties):
        return "Exports a JSON file that can later be used in Unreal"

    filepath: bpy.props.StringProperty(subtype='DIR_PATH')
    filename_ext = '.json'
    filter_glob: bpy.props.StringProperty(default='*.json', options={'HIDDEN'})

    def execute(self, context):
        time_start = time.time()
        scn = bpy.context.scene  # current scene
        bpy.ops.object.select_all(action='DESELECT')
        bpy.ops.object.select_pattern(pattern='*.mdl*', case_sensitive=False, extend=False)
        selected_anims = bpy.context.selected_objects  # get selected anims
        sel_anims = []
        vis_dict = {}

        for a in selected_anims:
            sel_anims.append(a.name)  # create list from selection

        print('------\nWorking')

        for frame in range(scn.frame_start, 2):
            scn.frame_set(frame)  # loop for frames
            for a in sel_anims:  # loop for selected anims
                vis_dict[a] = {}
                vis_dict[a][scn.frame_current] = str(bpy.context.scene.objects[a].hide_render)

        for frame in range(2, scn.frame_end):
            scn.frame_set(frame)  # loop for frames
            for a in sel_anims:  # loop for selected anims
                vis_dict[a][scn.frame_current] = str(bpy.context.scene.objects[a].hide_render)

        def clean(value, temp_dict):
            for k in temp_dict[:-1]:
                del value[k]

        def process(value):
            p = None
            temp_dict = []
            for k in list(value.keys()):
                if value[k] == p:
                    temp_dict.append(k)
                else:
                    clean(value, temp_dict)
                    p = value[k]
                    temp_dict = []
            clean(value, temp_dict)

        for v in vis_dict.values():
            process(v)

        export_file = open(self.filepath, 'w')
        json.dump(vis_dict, export_file, sort_keys=False, indent=2)
        export_file.close()

        bpy.ops.object.select_all(action='DESELECT')

        print('JSON file was exported in {:.2f} seconds'.format(time.time() - time_start))
        return {'FINISHED'}


class AgrToolsPanel(bpy.types.Panel):
    bl_idname = 'VIEW3D_PT_agr_tools'
    bl_label = 'AGR tools'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'AGR tools'

    def draw(self, context):
        layout = self.layout.column(align=True)
        scene = context.scene

        def row_ui(row_prop, row_name, row1_prop, row1_name, prop_trigger):
            row = layout.column(align=True).row(align=True)
            row.prop(scene, row_prop, text=row_name)
            row1 = row.row()
            row1.enabled = prop_trigger
            row1.prop(scene, row1_prop, text=row1_name)
            layout.separator()

        def row_ui2(row_prop, row_name):
            row = layout.column(align=True).row(align=True)
            row.prop(scene, row_prop, text=row_name)
            # layout.separator()

        layout.label(text='Presets:')
        row = layout.column(align=True).row(align=True)
        row.operator('opr.pist_preset', text='Pistol kills')
        row.operator('opr.rif_preset', text='Riffle kills')
        row = layout.column(align=True).row(align=True)
        row.operator('opr.remove_all_w_preset', text='Remove ALL weapons')
        row.operator('opr.remove_dropped_preset', text='Remove ALL dropped')
        row = layout.column(align=True).row(align=True)
        row.operator('opr.pl_and_pov_preset', text='Players and POV')
        row.operator('opr.pl_only_preset', text='Players only')
        layout.separator()

        layout.label(text='W Knives:')
        row_ui('remove_w_knives', 'Remove knives', 'remove_dropped_knives', 'Remove *dropped*', True)

        layout.label(text='W Guns:')
        row_ui('remove_w_guns', 'Remove guns', 'remove_dropped_guns', 'Remove *dropped*', True)

        layout.label(text='W Pistols:')
        row_ui('remove_w_pistols', 'Remove pistols', 'remove_dropped_pistols', 'Remove *dropped*', True)

        layout.label(text='W Nades:')
        row_ui('remove_w_nades', 'Remove nades', 'remove_dropped_nades', 'Remove *dropped*', True)

        layout.label(text='W c4:')
        row_ui('remove_w_c4', 'Remove c4', 'remove_dropped_c4', 'Remove *dropped*', True)

        layout.label(text='POV (viewmodels):')
        row_ui('remove_duplicates', 'Remove duplicates', 'remove_pov', 'Remove POV', True)

        layout.separator()
        row_ui2('remove_misc', 'Remove misc')
        row_ui2('place_animations', 'Place all animations at (0,0,0)')

        row = layout.column(align=True).row(align=True)
        row.enabled = scene.place_animations
        row.prop(scene, 'offset', text='Z Offset')
        layout.separator()

        layout.operator('opr.agr_tools', text='Clean')
        layout.separator()
        layout.operator('opr.export_visibility', text='Export visibility')


class PistolPreset(bpy.types.Operator):
    bl_idname = "opr.pist_preset"
    bl_label = "Pistol Kills"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.remove_w_knives = True
        context.scene.remove_dropped_knives = True
        context.scene.remove_w_guns = True
        context.scene.remove_dropped_guns = False
        context.scene.remove_w_pistols = True
        context.scene.remove_dropped_pistols = False
        context.scene.remove_w_nades = True
        context.scene.remove_dropped_nades = True
        context.scene.remove_w_c4 = False
        context.scene.remove_dropped_c4 = False
        context.scene.remove_pov = False
        context.scene.remove_misc = True
        context.scene.remove_duplicates = True
        context.area.tag_redraw()
        return {'FINISHED'}


class RifflePreset(bpy.types.Operator):
    bl_idname = "opr.rif_preset"
    bl_label = "Riffle kills"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.remove_w_knives = True
        context.scene.remove_dropped_knives = True
        context.scene.remove_w_guns = True
        context.scene.remove_dropped_guns = False
        context.scene.remove_w_pistols = True
        context.scene.remove_dropped_pistols = True
        context.scene.remove_w_nades = True
        context.scene.remove_dropped_nades = True
        context.scene.remove_w_c4 = False
        context.scene.remove_dropped_c4 = False
        context.scene.remove_pov = False
        context.scene.remove_misc = True
        context.scene.remove_duplicates = True
        context.area.tag_redraw()
        return {'FINISHED'}


class RemoveAllWPreset(bpy.types.Operator):
    bl_idname = "opr.remove_all_w_preset"
    bl_label = "Remove all weapons"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.remove_w_knives = True
        context.scene.remove_dropped_knives = False
        context.scene.remove_w_guns = True
        context.scene.remove_dropped_guns = False
        context.scene.remove_w_pistols = True
        context.scene.remove_dropped_pistols = False
        context.scene.remove_w_nades = True
        context.scene.remove_dropped_nades = False
        context.scene.remove_w_c4 = True
        context.scene.remove_dropped_c4 = False
        context.scene.remove_pov = False
        context.scene.remove_misc = True
        context.scene.remove_duplicates = True
        context.area.tag_redraw()
        return {'FINISHED'}


class RemoveAllDropped(bpy.types.Operator):
    bl_idname = "opr.remove_dropped_preset"
    bl_label = "Remove all dropped"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.remove_w_knives = False
        context.scene.remove_dropped_knives = True
        context.scene.remove_w_guns = False
        context.scene.remove_dropped_guns = True
        context.scene.remove_w_pistols = False
        context.scene.remove_dropped_pistols = True
        context.scene.remove_w_nades = False
        context.scene.remove_dropped_nades = True
        context.scene.remove_w_c4 = False
        context.scene.remove_dropped_c4 = True
        context.scene.remove_pov = False
        context.scene.remove_misc = True
        context.scene.remove_duplicates = True
        context.area.tag_redraw()
        return {'FINISHED'}


class PlayersAndPov(bpy.types.Operator):
    bl_idname = "opr.pl_and_pov_preset"
    bl_label = "Players and POV"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.remove_w_knives = True
        context.scene.remove_dropped_knives = True
        context.scene.remove_w_guns = True
        context.scene.remove_dropped_guns = True
        context.scene.remove_w_pistols = True
        context.scene.remove_dropped_pistols = True
        context.scene.remove_w_nades = True
        context.scene.remove_dropped_nades = True
        context.scene.remove_w_c4 = True
        context.scene.remove_dropped_c4 = True
        context.scene.remove_pov = False
        context.scene.remove_misc = True
        context.scene.remove_duplicates = True
        context.area.tag_redraw()
        return {'FINISHED'}


class PlayersOnly(bpy.types.Operator):
    bl_idname = "opr.pl_only_preset"
    bl_label = "Players Only"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.remove_w_knives = True
        context.scene.remove_dropped_knives = True
        context.scene.remove_w_guns = True
        context.scene.remove_dropped_guns = True
        context.scene.remove_w_pistols = True
        context.scene.remove_dropped_pistols = True
        context.scene.remove_w_nades = True
        context.scene.remove_dropped_nades = True
        context.scene.remove_w_c4 = True
        context.scene.remove_dropped_c4 = True
        context.scene.remove_pov = True
        context.scene.remove_misc = True
        context.scene.remove_duplicates = False
        context.area.tag_redraw()
        return {'FINISHED'}


CLASSES = [
    AgrTools,
    AgrToolsPanel,
    AgrVisibility,
    PistolPreset,
    RifflePreset,
    RemoveAllWPreset,
    RemoveAllDropped,
    PlayersAndPov,
    PlayersOnly,
]


def register():
    for (prop_name, prop_value) in PROPS:
        setattr(bpy.types.Scene, prop_name, prop_value)

    for smth in CLASSES:
        bpy.utils.register_class(smth)


def unregister():
    for (prop_name, _) in PROPS:
        delattr(bpy.types.Scene, prop_name)

    for smth in CLASSES:
        bpy.utils.unregister_class(smth)


if __name__ == '__main__':
    register()
